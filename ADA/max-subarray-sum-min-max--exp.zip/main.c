#include <stdio.h>
#include<limits.h>
int max(int a, int b) { return (a > b) ? a : b; }

int max1(int a, int b, int c) { return max(max(a, b), c); }

int crosssum(int arr[],int l,int m,int h){
    int sum=0,lhs=INT_MIN;
    for(int i=m;i>=l;i--){
        sum=sum+arr[i];
        if(lhs<sum){
            lhs=sum;
        }
    }
    sum=0;
    int rhs=INT_MIN;
    for(int i=m+1;i<=h;i++){
        sum=sum+arr[i];
        if(rhs<sum){
            rhs=sum;
        }
    }
    return max1(lhs,rhs,lhs+rhs);
}

int maxsubarray(int arr[],int l,int h){
    
    if(l==h){
        return arr[l];
    }
  
    int mid=(l+h)/2;
    
    return max1(maxsubarray(arr,l,mid),maxsubarray(arr,mid+1,h),crosssum(arr,l,mid,h));
}

int main(){
    int arr[]={-1,-2,4,5,-3,10,-6};
    int n= sizeof(arr)/sizeof(arr[0]);
    int l=0,h=n-1;
    int max_sum=maxsubarray(arr,l,h);
    printf("Maximum contiguous sum is %d\n",max_sum);
    int maxele=INT_MIN;
    for(int i=0;i<n;i++){
        if(arr[i]>maxele){
            maxele=arr[i];
        }
    }
    printf("The max element of an array is:%d\n",maxele);
    int minele=arr[0];
    for(int i=1;i<n;i++){
        if(arr[i]<minele){
            minele=arr[i];
        }
    }
    printf("The min element of an array is:%d\n",minele);
}